import java.util.Scanner;
public class Library {

    
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("\nEnter Call ID");
        String i = sc.nextLine();
        System.out.println("\nEnter Issue:");
        String s=sc.nextLine();
        System.out.println("Enter the title ");
        String t = sc.nextLine();
        Resource r[] = new Resource[3];
        r[0] = new Resource(i, t);
        Journal j = new Journal(i,t,s);
        System.out.println(j.Summary()); //Printing Journal Details 
        j.borrowed(); //Borrowing the Journal Details

        System.out.println(j.summary());
        //book data input 
        System.out.println("\nEnter Call ID:");
        i=sc.nextLine();
        System.out.println("\n Enter the Title ");
        t = sc.nextLine();
        System.out.println("\nEnter Author:");
        s=sc.nextLine();
        Book b= new Book(i,t,s);
        r[1] = new Resource(i, t);
        System.out.println(b.summary());
        System.out.println("\nAfter Borrow");
        b.borrowed();
        r[1].borrowed();
        System.out.println(b.summary());
        r[2] = new Resource(i, t);
        int ct = CountBorrowedBooks(r);

        System.out.println("\n Total Books in Library : " + r.length);
        System.out.println("\n Total Borrowed Books in Library: " + ct);
        System.out.println("Total Available Books  in Library: " + (r.length-ct));
        
        

    }
    public static int CountBorrowedBooks(Resource r[]){
        int count = 0;
        for(int i = 0; i<r.length; i++){
            if(r[i].getBorrowed()==true)
            count++;
        }
        return count;
    }
}
