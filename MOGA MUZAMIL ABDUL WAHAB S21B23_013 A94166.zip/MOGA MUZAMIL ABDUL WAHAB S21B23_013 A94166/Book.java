public class Book extends Resource {

    String Author;
    //Parameterized constructor passing parameters to super class 
    public Book(String c, String t, String a){
        super(c,t);
        Author=a;
    }
}
